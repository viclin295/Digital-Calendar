/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalcalendarteam3vw;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import java.text.SimpleDateFormat;
import java.util.Timer;
import java.util.Date;

/**
 *
 * @author wxz5098
 */

public final class MainMenuFrame extends JFrame
{
    String [] columns = {"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};
    DefaultTableModel model = new DefaultTableModel(null,columns);
    Calendar cal = new GregorianCalendar();
    JTable table = new JTable(model);
    JLabel label, descriptionLabel, dateLabel, timeLabel, clockLabel;
    JLabel [] alarmLabel;
    JTextField [] alarmTextField;
    JButton prevButton, nextButton, saveButton, moreAlarmButton, setAlarmButton; 
    JPanel calendarPanel, menuPanel, timePanel, descriptionPanel, eventPanel, notiPanel, clockPanel, alarmPanel;
    JTextArea message, description;
    JScrollPane pane, descriptionPane, eventPane;
    JTextField dateField, timeField;
    String month;
    JComboBox hour1Combo, minute1Combo,hour2Combo, minute2Combo;
    TableCellRenderer renderer;
    int year;
    int timerCount = 0;
    int numAlarm = 1;
    static Events e = new Events();
    
    public MainMenuFrame() throws IOException
    {
        this.alarmLabel = new JLabel[numAlarm];
        this.alarmTextField = new JTextField[numAlarm];
        label = new JLabel("Calendar");
        label.setHorizontalAlignment(SwingConstants.CENTER);
        
        message = new JTextArea();
        descriptionLabel = new JLabel("Description");
        description = new JTextArea();
        description.setLineWrap(true);
        description.setWrapStyleWord(true);
        
        saveButton = new JButton("Save");
        saveButton.addActionListener((ActionEvent ae) -> {
            String date = dateField.getText();
            String event = description.getText();
            String time = getTime();
            
            try {
                e.writeToText(event, time, date);
            } catch (IOException ex) {
                Logger.getLogger(MainMenuFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
 
        prevButton = new JButton("<-");
        prevButton.addActionListener((ActionEvent ae) -> {
            cal.add(Calendar.MONTH, -1);
            try {
                updateMonth();
            } catch (IOException ex) {
                Logger.getLogger(MainMenuFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
 
        nextButton = new JButton("->");
        nextButton.addActionListener((ActionEvent ae) -> {
             cal.add(Calendar.MONTH, +1);
            try {
                updateMonth();
            } catch (IOException ex) {
                Logger.getLogger(MainMenuFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        }); 
        
        moreAlarmButton = new JButton("Add Alarm");
        moreAlarmButton.addActionListener((ActionEvent ae) -> {
            numAlarm++;
            repaint();
        });
        
        setAlarmButton = new JButton("Set Alarm");
        setAlarmButton.addActionListener((ActionEvent ae) -> {
           //nothing
        });
        
        clockLabel = new JLabel("");
        //for(timerCount = 0;timerCount < 1000;timerCount++)
       // {
            clockLabel.setText("" + cal.get(Calendar.HOUR) + ":" + cal.get(Calendar.MINUTE));
         //   if(timerCount == 999)
         //   {
           //     timerCount = 0;
         //   }
      //  }
 
       // int delay = 1000; //milliseconds
       // ActionListener taskPerformer = (ActionEvent evt) -> {
        //    clockLabel.setText("" + cal.get(Calendar.HOUR) + ":" + cal.get(Calendar.MINUTE));
        //    revalidate();
       // };
        //new Timer(delay, taskPerformer).start();
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                String string = new SimpleDateFormat("HH:mm:ss").format(new Date());
                clockLabel.setText(string);
            }
        }, 0, 1000);
        createPanel();
    }
    
    public void createPanel() throws IOException
    {
        menuPanel =  new JPanel();
        menuPanel.setPreferredSize(new Dimension(1000,1000));
        menuPanel.setLayout(new GridLayout(2,2));
        
        //Description Panel
        descriptionPanel = new JPanel();
        descriptionPanel.setLayout(new BorderLayout());
        descriptionPanel.setOpaque(true);
        descriptionPanel.setBackground(Color.WHITE);
        descriptionPanel.setBorder(BorderFactory.createTitledBorder("Description"));
        descriptionPane = new JScrollPane(message);
        descriptionPanel.add(descriptionPane, BorderLayout.CENTER);
            
            //Event Panel
            eventPanel = new JPanel();
            eventPanel.setLayout(new BorderLayout());
            eventPanel.setBackground(Color.WHITE);
            eventPanel.setBorder(BorderFactory.createTitledBorder("Event Description"));
            eventPane = new JScrollPane(description);
            eventPanel.setPreferredSize(new Dimension(300,200));
            eventPanel.add(descriptionLabel);
            eventPanel.add(eventPane, BorderLayout.CENTER);
            eventPanel.add(saveButton, BorderLayout.SOUTH);
        
        descriptionPanel.add(eventPanel, BorderLayout.WEST);
        
            //notifcation panel
            notiPanel = new JPanel();
            //notiPanel.setLayout(new BorderLayout());
            //notiPanel.setOpaque(true);
            notiPanel.setBackground(Color.WHITE);
            notiPanel.setBorder(BorderFactory.createTitledBorder("Notification Setting"));
            notiPanel.setPreferredSize(new Dimension(300,150));
            dateLabel = new JLabel("Date - Month_Day_Year");
            dateField = new JTextField(15);
            dateField.setEditable(false);

            
            //TIME COMBO BOX
            JLabel colon = new JLabel(":");
            JLabel colon2 = new JLabel(":");
            
            hour1Combo = new JComboBox();
            hour1Combo.setEditable(true);
        
            minute1Combo = new JComboBox();
            minute1Combo.setEditable(true);

            hour2Combo = new JComboBox();
            hour2Combo.setEditable(true);

            minute2Combo = new JComboBox();
            minute2Combo.setEditable(true);
            
            //LOOP FOR HOURS
            int add = 0;
            for(int hour1 = 0; hour1 < 24; hour1++)
            {
                String min;
                add = hour1;
                min = "" + add;
                if(min.length() < 2)
                {
                    min = "0" + min;
                }

                hour1Combo.addItem(min);
                hour2Combo.addItem(min);
            }
            
            //loop for minutes
            for(int minute1 = 0; minute1 < 60; minute1++)
            {
                String min;
                add = minute1;
                min = "" + add;
                if(min.length() < 2)
                {
                    min = "0" + min;
                }
                minute1Combo.addItem(min);
                minute2Combo.addItem(min);
            }
            
            notiPanel.add(dateLabel);
            notiPanel.add(dateField);
            notiPanel.add(hour1Combo);
            notiPanel.add(colon);
            notiPanel.add(minute1Combo);
            notiPanel.add(hour2Combo);
            notiPanel.add(colon2);
            notiPanel.add(minute2Combo);
            
            
            
        eventPanel.add(notiPanel, BorderLayout.NORTH);

        //Alarm Panel
        alarmPanel = new JPanel();
        alarmPanel.setOpaque(true);
        alarmPanel.setBackground(Color.WHITE);
        for(int p = 0; p < numAlarm; p++)
        {
            alarmLabel[p] = new JLabel("Alarm " + p);
            alarmTextField[p] = new JTextField();
            alarmPanel.add(alarmLabel[p]);
            alarmPanel.add(alarmTextField[p]);
        }
        alarmPanel.add(moreAlarmButton);
        alarmPanel.add(setAlarmButton);
        
        clockPanel = new JPanel();
        clockPanel.setLayout(new BorderLayout());
        clockPanel.setOpaque(true);
        clockPanel.setBackground(Color.WHITE);
        clockPanel.setBorder(BorderFactory.createTitledBorder("Alarm"));
        clockPanel.add(clockLabel, BorderLayout.NORTH);
        clockPanel.add(alarmPanel, BorderLayout.WEST);
        descriptionPanel.add(clockPanel, BorderLayout.EAST);
        
        //CalendarPanel
        calendarPanel = new JPanel();
        calendarPanel.setLayout(new BorderLayout());
        calendarPanel.setOpaque(true);
        calendarPanel.setBackground(Color.WHITE);
        calendarPanel.setBorder(BorderFactory.createTitledBorder("Calendar"));       
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BorderLayout());
        buttonPanel.add(prevButton,BorderLayout.WEST);
        buttonPanel.add(label,BorderLayout.CENTER);
        buttonPanel.add(nextButton,BorderLayout.EAST);
        
        table = new JTable(model) {
    @Override
    public Component prepareRenderer(TableCellRenderer renderer, int row, int col) {
        Component comp = super.prepareRenderer(renderer, row, col);
        try {
            if (e.searchEvent(month + "_" + table.getValueAt(row, col) + "_" + year) ==  true)
            {
                comp.setBackground(Color.LIGHT_GRAY);
            }
            else
            {
                comp.setBackground(Color.WHITE);
            }
        } catch (IOException ex) {
            Logger.getLogger(MainMenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            updateMonth();
        } catch (IOException ex) {
            Logger.getLogger(MainMenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
        return comp;
        }
    };  
        
        table.setRowHeight(75);
        pane = new JScrollPane(table);
        
        //Mouse Event for Calendar
        table.setColumnSelectionAllowed(true);
        table.setRowSelectionAllowed(true);
        table.setCellSelectionEnabled(true);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.addMouseListener(new MouseAdapter() {
        @Override
        public void mousePressed(MouseEvent e) {
            dateField.setText(month + "_" + table.getValueAt(table.getSelectedRow(), table.getSelectedColumn())
                                        + "_" + year);
            String txtName = "";
            txtName = txtName + dateField.getText();
            try {
                message.setText("");
                setMessage(txtName);
            } catch (IOException ex) {
                Logger.getLogger(MainMenuFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        });

        calendarPanel.add(buttonPanel,BorderLayout.NORTH);
        calendarPanel.add(pane,BorderLayout.CENTER);
        updateMonth();
        
        menuPanel.add(descriptionPanel);
        menuPanel.add(calendarPanel);
        add(menuPanel);
    }
    
  //GET TIME FROM COMBOBOXES
   private String getTime() {
        String createTime;

        createTime = String.valueOf(hour1Combo.getSelectedItem()) + ":" + String.valueOf(minute1Combo.getSelectedItem()) + 
                " to " + String.valueOf(hour2Combo.getSelectedItem()) + ":" + String.valueOf(minute2Combo.getSelectedItem());
        return createTime;
    }
    
  public void updateMonth() throws IOException 
  {
    cal.set(Calendar.DAY_OF_MONTH, 1);
 
    month = cal.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.US);
    year = cal.get(Calendar.YEAR);
    label.setText(month + " " + year);
 
    int startDay = cal.get(Calendar.DAY_OF_WEEK);
    int numberOfDays = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
    int weeks = cal.getActualMaximum(Calendar.WEEK_OF_MONTH);
 
    model.setRowCount(0);
    model.setRowCount(weeks);
 
    int i = startDay-1;
    for(int day=1;day<=numberOfDays;day++){
      model.setValueAt(day, i/7 , i%7 );    
      i = i + 1;
    }
  }
  
  public void setMessage(String date) throws IOException
  {
      message.setText(e.readText(date));
  }

}
