/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalcalendarteam3vw;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Owner
 */
public class Alarm {
    String currentTime;
    String selectedTime;
    static final SimpleDateFormat timeFormat = new SimpleDateFormat("HH.mm");
    
    public Alarm()
    {
        Timestamp time = new Timestamp(System.currentTimeMillis());
        currentTime = time.toString();
    }
    
    public void ringAlarm(String time)
    {
        selectedTime = time;
        if(currentTime.equals(selectedTime))
        {
            System.out.println("RINGRINGRINGRINGRING");
            //ring
        }
    }
}
